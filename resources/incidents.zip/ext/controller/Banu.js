sap.ui.define(["sap/m/MessageToast"],function(n){"use strict";return{none:function(e){n.show("Custom handler invoked.")}}});
//# sourceMappingURL=Banu.js.map